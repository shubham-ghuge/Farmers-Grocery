<?php
include ('header.php');
?>
<!DOCTYPE html>
<hr>
<h2 class="text-center">GRAINS</h2>
<hr>
<?php getgrains(); ?>
<hr>
<hr>
<hr>
  </body>
</html>
<?php
include ('footer.php');
?>