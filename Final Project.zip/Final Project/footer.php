<html>
<body>
<!--footer code-->
<hr>
<hr>
    <div class="container text-white bg-dark p-4">
      <div class="row">
        <div class="col-md-4 col-lg-5 col-6">
          <address>
          <strong>farmer's grocery, Inc.</strong><br>
BORIVALI EAST,MUMBAI
          </address>
          <address>
        <strong>SHUBHAM GHUGE</strong>
        <br>
            <a href="mailto:#">shubhamghuge34@.com</a>
          </address>
        </div>
      </div>
    </div>
    <footer class="text-center">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <p>Copyright © MyWebsite. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
   <script src="js/popper.min.js"></script>
    <script src="js/bootstrap-4.3.1.js"></script> 
  </body>
</html>