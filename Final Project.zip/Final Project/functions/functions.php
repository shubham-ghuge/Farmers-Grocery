<?php
require "./includes/db_connetion.php";
/*
function getPro($flag = '')
{
    global $con;
    $get_pro = "select * from products";
    $run_pro = mysqli_query($con,$get_pro);
    $count_pro = mysqli_num_rows($run_pro);
    if($count_pro==0){
        echo "<h2> No Product found in selected criteria </h2>";
    }
    while($row_pro = mysqli_fetch_array($run_pro))
    {
        $pro_id = $row_pro['pro_id'];
        $pro_cat = $row_pro['pro_cat'];
      //  $pro_brand = $row_pro['pro_brand'];
        $pro_title = $row_pro['pro_title'];
        $pro_price = $row_pro['pro_price'];
        $pro_image = $row_pro['pro_image'];
        $pro_desc = $row_pro['pro_desc'];

                echo "
            <div class='container'>
              <div class='row text-center'>
                <div class='col-md-4 col-lg-4'>
                    <div class='card'>
                        <img src='admin/product_images/$pro_image' alt='Card image cap' width='400' height='200' class='card-img-top'>
                        <div class='card-body'>
                            <h5 class='card-title'><strong>$pro_title @ $pro_price INR/KG</strong></h5>
                            <p class='card-text'>$pro_desc</p>
                            <a href='home.php?add_cart=$pro_id'><button class='btn btn-primary'>Add to Cart</button></a>
                        </div>
                    </div>
                </div>
                </div>
            </div>
                
        ";
    }
}
*/

//get fruits
function getfruits($flag = ''){
    global $con;
    $get_pro = "select * from products where pro_cat=1";
    $run_pro = mysqli_query($con,$get_pro);
    $count_pro = mysqli_num_rows($run_pro);
    if($count_pro==0){
        echo "<h2> No Product found in selected criteria </h2>";
    }
   while($row_pro = mysqli_fetch_array($run_pro))
    {
        $pro_id = $row_pro['pro_id'];
        $pro_cat = $row_pro['pro_cat'];
      //  $pro_brand = $row_pro['pro_brand'];
        $pro_title = $row_pro['pro_title'];
        $pro_price = $row_pro['pro_price'];
        $pro_image = $row_pro['pro_image'];
        $pro_desc = $row_pro['pro_desc'];

                echo "
            <div class='container'>
              <div class='row text-center'>
                <div class='col-md-4'>
                    <div class='card'>
                        <img src='admin/product_images/$pro_image' alt='Card image cap' width='400' height='200' class='card-img-top'>
                        <div class='card-body'>
                            <h5 class='card-title'><strong>$pro_title @ $pro_price INR/KG</strong></h5>
                            <p class='card-text'>$pro_desc</p>
                            <a href='home.php?add_cart=$pro_id'><button class='btn btn-primary'>Add to Cart</button></a>
                        </div>
                    </div>
                </div>
                </div>
            </div>
                
        ";
    }
}

//get veggetables
function getveggies($flag = ''){
    global $con;
    $get_pro = "select * from products where pro_cat=3";
    $run_pro = mysqli_query($con,$get_pro);
    $count_pro = mysqli_num_rows($run_pro);
    if($count_pro==0){
        echo "<h2> No Product found in selected criteria </h2>";
    }
   while($row_pro = mysqli_fetch_array($run_pro))
    {
        $pro_id = $row_pro['pro_id'];
        $pro_cat = $row_pro['pro_cat'];
      //  $pro_brand = $row_pro['pro_brand'];
        $pro_title = $row_pro['pro_title'];
        $pro_price = $row_pro['pro_price'];
        $pro_image = $row_pro['pro_image'];
        $pro_desc = $row_pro['pro_desc'];

                echo "
            <div class='container'>
              <div class='row text-center'>
                <div class='col-md-4'>
                    <div class='card'>
                        <img src='admin/product_images/$pro_image' alt='Card image cap' width='400' height='200' class='card-img-top'>
                        <div class='card-body'>
                            <h5 class='card-title'><strong>$pro_title @ $pro_price INR/KG</strong></h5>
                            <p class='card-text'>$pro_desc</p>
                            <a href='home.php?add_cart=$pro_id'><button class='btn btn-primary'>Add to Cart</button></a>
                        </div>
                    </div>
                </div>
                </div>
            </div>
                
        ";
    }
}

//get grains
function getgrains($flag = ''){
    global $con;
    $get_pro = "select * from products where pro_cat=2";
    $run_pro = mysqli_query($con,$get_pro);
    $count_pro = mysqli_num_rows($run_pro);
    if($count_pro==0){
        echo "<h2> No Product found in selected criteria </h2>";
    }
   while($row_pro = mysqli_fetch_array($run_pro))
    {
        $pro_id = $row_pro['pro_id'];
        $pro_cat = $row_pro['pro_cat'];
      //  $pro_brand = $row_pro['pro_brand'];
        $pro_title = $row_pro['pro_title'];
        $pro_price = $row_pro['pro_price'];
        $pro_image = $row_pro['pro_image'];
        $pro_desc = $row_pro['pro_desc'];

                echo "
            <div class='container'>
              <div class='row text-center'>
                <div class='col-md-4'>
                    <div class='card'>
                        <img src='admin/product_images/$pro_image' alt='Card image cap' width='400' height='200' class='card-img-top'>
                        <div class='card-body'>
                            <h5 class='card-title'><strong>$pro_title @ $pro_price INR/KG</strong></h5>
                            <p class='card-text'>$pro_desc</p>
                            <a href='home.php?add_cart=$pro_id'><button class='btn btn-primary'>Add to Cart</button></a>
                        </div>
                    </div>
                </div>
                </div>
            </div>
                
        ";
    }
}


//getting the user IP address
function getIp() {
    $ip = $_SERVER['REMOTE_ADDR'];

    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    return $ip;
}

function cart(){
    if(isset($_GET['add_cart'])){
        global $con;
        $ip = getIp();
        $pro_id = $_GET['add_cart'];
        $check_pro = "select * from cart where ip_add = '$ip' AND p_id='$pro_id '";
        $run_check = mysqli_query($con,$check_pro);
        if(mysqli_num_rows($run_check)>0){
            echo "";
        } else {
            $insert_pro = "insert into cart (p_id, ip_add) VALUES
                      ('$pro_id','$ip')";
            $run_pro = mysqli_query($con,$insert_pro);
            if($run_pro)
                header('location:'.$_SERVER['PHP_SELF']);
        }
    }
}

function total_price(){
    global $con;
    $ip = getIp();
    $total = 0;
    $sel_price = "select * from cart where ip_add = '$ip'";
    $run_price = mysqli_query($con,$sel_price);
    while($cart_row = mysqli_fetch_array($run_price)){
        $pro_id = $cart_row['p_id'];
        $pro_qty = $cart_row['qty'];
        $pro_price = "select * from products where pro_id = '$pro_id'";
        $run_pro_price = mysqli_query($con, $pro_price);
        while ($pro_row = mysqli_fetch_array($run_pro_price)){
            $pro_price = $pro_row['pro_price'];
            $pro_price_all_items = $pro_price * $pro_qty;
            $total += $pro_price_all_items;
        }
    }
    echo 'Rs '.$total.'/-';
}


//getting the total added items.
function total_items(){
    global $con;
    $ip = getIp();
    $get_items = "select * from cart where ip_add='$ip'";
    $run_items = mysqli_query($con,$get_items);
    $count_items = 0;
    while($row = mysqli_fetch_array($run_items))
        $count_items += $row['qty'];
    echo $count_items;
}


?>
