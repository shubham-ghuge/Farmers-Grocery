<?php
session_start();
include ('functions/db_connect.php');
if(!isset($_SESSION['user_email'])){
    header('location: flogin.php?not_admin=You are not Admin!');
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Farmer's portal</title>
    <!-- Bootstrap -->
    <link href="assets/css/bootstrap-4.3.1.css" rel="stylesheet">
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container">
        <a class="navbar-brand" href="/Final%20Project/index.php"><img src="icon.jpg" alt="" width="70" height="70" class="img-thumbnail img-fluid"/> farmers grocery</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="findex.php">Farmer's portal<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item"> </li>
            <li class="nav-item dropdown">
				    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Your Products</a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <p><a class="dropdown-item" href="findex.php?view_products">View products</a></p>
				      <div class="dropdown-divider"></div>
				      <p><a class="dropdown-item" href="findex.php?insert_product">Add new products</a></p>
				      <div class="dropdown-divider"></div>
				    </div>
            </li>
            <li class="nav-item"> </li>
              <li class="nav-item dropdown">
				      <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Your Orders</a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <p><a class="dropdown-item" href="findex.php?view_orders">View all orders</a></p>
		  		        <div class="dropdown-divider"></div>
			   	        <p><a class="dropdown-item" href="findex.php?view_customers">view your customers</a></p>
				          <div class="dropdown-divider"></div>
				          <p><a class="dropdown-item" href="findex.php?view_payments">view your payments</a></p>
				      </div>
              </li>

            <li class="nav-item"> <a class="nav-link" href="logout.php">logout</a></li>
          </ul>
          <form class="form-inline my-2 my-lg-0">
            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
          </form>
        </div>
      </div>
      </div>
    </nav>
     <hr>

    
                              <?php
                        if(isset($_GET['insert_product'])){
                            include ('insert_product.php');
                        }
                        else if(isset($_GET['view_products'])){
                            include ('view_products.php');
                        }
                        else if(isset($_GET['edit_pro'])){
                            include ('edit_pro.php');
                        }
                        else if(isset($_GET['del_pro'])){
                            include ('del_pro.php');
                        }
                        else if(isset($_GET['view_categories'])){
                            include ('view_categories.php');
                        }
                        else if(isset($_GET['insert_category'])){
                            include ('insert_category.php');
                        }
                        else if(isset($_GET['edit_cat'])){
                            include ('edit_cat.php');
                        }
                        else if(isset($_GET['del_cat'])){
                            include ('del_cat.php');
                        }
                        else if(isset($_GET['view_brands'])) {
                            include('view_brands.php');
                        }
                        else if(isset($_GET['insert_brand'])) {
                            include('insert_brand.php');
                        }
                        else if(isset($_GET['edit_brand'])) {
                            include('edit_brand.php');
                        }
                        else if(isset($_GET['del_brand'])) {
                            include('del_brand.php');
                        }
                        else if(isset($_GET['view_customers'])){
                            include ('view_customers.php');
                        }
                        else if(isset($_GET['del_customer'])){
                            include ('del_customer.php');
                        }
                        ?>
<hr>
<h2 class="text-center text-primary"><?php echo @$_GET['logged_in']?></h2>
<hr>
    <div class="container">
      <script>
            $(document).ready(function () {

                $('#sidebarCollapse').on('click', function () {
                    $('#sidebar').toggleClass('active');
                });

            });
        </script>
    </div>
   <hr>
<hr>
    <div class="container text-white bg-dark p-4">
      <div class="row">
        <div class="col-md-4 col-lg-5 col-6">
          <address>
          <strong>farmer's grocery, Inc.</strong><br>
BORIVALI EAST,MUMBAI
          </address>
          <address>
        <strong>SHUBHAM GHUGE</strong>
        <br>
            <a href="mailto:#">shubhamghuge34@.com</a>
          </address>
        </div>
      </div>
    </div>
    <footer class="text-center">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <p>Copyright © MyWebsite. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap-4.3.1.js"></script>
  </body>
</html>