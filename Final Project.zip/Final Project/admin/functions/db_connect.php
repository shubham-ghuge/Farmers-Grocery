<?php
$con = mysqli_connect("localhost","root","","check");
if(!$con)
    die("connection failed");