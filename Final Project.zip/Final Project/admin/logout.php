<?php
session_start();
session_destroy();
header('location:flogin.php?logged_out=You have logged out');